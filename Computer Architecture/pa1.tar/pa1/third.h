#ifndef __THIRD_H__
#define __THIRD_H__

typedef struct Node{
	int val;
	struct Node *next;
} Node;



#endif // __THIRD_H__