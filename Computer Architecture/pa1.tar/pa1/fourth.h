#ifndef __FOURTH_H__
#define __FOURTH_H__

// Hashtable struct definition of size 1000
typedef struct Hashtable{
	int size;
	int table[1000]; 
}Hashtable;



#endif // __FOURTH_H__